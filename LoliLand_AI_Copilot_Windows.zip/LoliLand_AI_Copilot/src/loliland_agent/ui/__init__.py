"""Local Qt dashboard."""
